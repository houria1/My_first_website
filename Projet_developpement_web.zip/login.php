
<!DOCTYPE html>
<html>
    <head>
    <title>Login Form</title>
    <link type="text/css" rel="stylesheet" href="css/template.css">
    <meta charset="UTF-8">
    </head>
    <body>
    <script type="text/javascript" src="javascipt.js"></script>

        <form action="traitement2.php" method="post" id="form_login" > 
        
        <h1>Login Form</h1>
        
        <div class="form_grp">
            <label for="Nom">Username</label>
            <input name="username" type="text" class="form-control" required>
        </div>


        <div class="form_grp">
            <label for="Email">Useremail </label>
            <input name="email" type="text" class="form-control" required>
        </div>

        <div class="form_grp">
            <label for="Mot de passe">Password </label>
            <input name="mdp" type="text" class="pw" required>

        </div>

        <div class="form_grp">
            <input type="checkbox" name="remem" id="remember">
            <label for="Remember me!">Rememberme!</label>
        </div>

        <div class="form_grp">
            <div><input type="submit" name="login" value="Login" id="btn_login" required></span> </div>   

        </div>

         <p id="new_user">If you are New , so<a href='Create.php'><b> Create Account </b></a></p>

        </form>

        <div id="cookie_container"> 
         
            <p>
            We use cookies in this website to give you the best experience on our
                 site and show you relevant ads. To find out more, read our
                 <a href="#">privacy policy</a> and <a href="#">cookie policy</a>.
            </p>
            <button onclick='document.getElementById("cookie_container").style.display = "none"; '  id="cookie_btn"> Accept</button>
            
        </div>
    </body>
</html>