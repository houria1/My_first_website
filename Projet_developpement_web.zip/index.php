
<!DOCTYPE html>
<html lang="fr">
<head>

<title>Perfuma</title>
<meta charset="UTF-8">
<link type="text/css" rel="stylesheet" href="css/template.css">

</head >
<div class="loader_container"> 
  <div class="loader"></div> 
</div>
 
<body class="special">
 
 <script type="text/javascript" src="javascipt.js"></script>
 

<nav >

     <ul>    
	   <li><a href ="index.php">Home</a></li>
      <li><a href = "Industrieparfum.php">Industrie des Parfums</a></li>
          <li><a href = "commande.php">Commande</a></li>
          <li><a href = "PsycoParfum.php">PsycoParfum</a></li>
          <li><a href = "historique.php">Historique</a></li>
	</ul>	
</nav>


       <div class="popup" onclick="ma_fonction()">Click me!
             <span class="popup_text" id="mon_popup"> 🌹  إستغفر الله  🌹 </span>
       </div>
<?php
    
    session_start();
    if(session_status() == 2 and !empty($_SESSION)){
      
     
      
         echo "<b><p style='font-size:20px ; color:hotpink ; border-left:solid'>Welcome🔔 :)"." ". $_SESSION['username']."<br>";
          echo "<a href='logout.php' style='font-size:20px ; color:hotpink ; hover:white' >logout</a>";

    
    }
?>
      
      

       <h1 style="text-align:center" ><b><em>Your Perfuma </em></b> </h1> 
       <img src="images/source.gif" alt="Perfuma" width="60px" height="60px">

       <div >
        <p class="citation "><em>“La femme est une fleur qui ne donne son parfum qu'à l'ombre”</em></p> 
  
  
        <img src="images/source.gif" alt="Perfuma" width="60px" height="60px">

        <p class="citation "><em>“ Les plaisirs sont comme les parfums, il faut les éloigner pour les mieux sentir encore”</em></p> 
        <img src="images/source.gif" alt="Perfuma" width="60px" height="60px">

      </div>

      <div> <p class="citation "><em>“Ce n'est pas l'épine qui protège la rose, c'est son parfum”</em></p>
       <img src="images/source.gif" alt="Perfuma" width="60px" height="60px">
        <p class="citation "><em>“Les paroles des cœurs unis sont odorantes comme des parfums”</em></p>
 
        <img src="images/source.gif" alt="Perfuma" width="60px" height="60px">
      </div>
      </p>
  
  
  <footer >
   <p id="log"> <a href="login.php">se connecter</a></p>
   <img src="images/icones.jpg" alt="social_media" width="200px" height="40px" usemap="#cliquable">
    <map name="cliquable">
        <area shape="rect" coords="1,1,40,50" href="https://www.instagram.com/">
        <area shape ="rect" coords="45,1,85,50" href="https://twitter.com/"  > 
        <area shape ="rect" coords="87,1,120,50" href="https://facebook.com"  > 
        <area shape="rect" coords="125,1,160,50" href="https://www.pinterest.fr/"  >
        <area shape="rect" coords="163,1,198,50" href="https://www.linkedin.com/"  >
	</map>
	<div class="info">
	 <div style="color:black">
	 <p >Toujours la Pour Vous !</p><br>
	 <p>Vous Méritez le meilleur !</p>
	 </div>
	 <h6 style="color:black">Copyright © 2021 Perfuma™ </h6>
  </footer>
 
    </div>
   
</body>
</html>