<!DOCTYPE html>
<html lang="fr">
<head>
<title>Perfuma/PsycoParfum</title>
<meta charset="UTF-8">
<link type="text/css" rel="stylesheet" href="css/template.css">
</head>

<body>

<script src="javascipt.js"></script>


<div class="loader_container"> 
  <div class="loader"></div> 
</div>
<div class="black">
<nav>

     <ul>
	   
     
      <li><a href ="index.php">Home</a></li>
      <li><a href = "Industrieparfum.php">Industrie des Parfums</a></li>
          <li><a href = "commande.php">Commande</a></li>
          <li><a href = "PsycoParfum.php">PsycoParfum</a></li>
          <li><a href = "historique.php">Historique</a></li>
	</ul>	
</nav>
<div class="popup" onclick="ma_fonction()">Click me!
  <span class="popup_text" id="mon_popup"> 🌹  إستغفر الله  🌹 </span>
</div>

</div>
</div>
<?php
 
 session_start();
 if(session_status() == 2 and !empty($_SESSION)){
   
  
   
      echo "<b><p style='font-size:20px ; color:hotpink ; border-left:solid'>Welcome🔔 :)"." ". $_SESSION['username']."<br>";
       echo "<a href='logout.php' style='font-size:20px ; color:hotpink ; hover:white' >logout</a>";

 
 }
?>
      
<div class="group">
<div class="psy">
<h5> La Sonté mentalle dons votre parfum prefrere</h5> 
<img class="rota" src="images/best.jpg" alt="fleur" width="380px" height="200px">
<p>  Notre parfum est une carte de visite sensorielle. <br>S’il habille notre personnalité et notre parcours de vie<br> d’une senteur si caractéristique, <br>il peut aussi exacerber nos émotions, voire parfois,<br> dans notre rencontre avec l’autre,<br> occasionner un réel bouleversement sentimental.</p>

</div>
<div  class="psy">
<h5> Derriere les Aromes</h5> 
<img  class="rota" src="images/best.jpg" alt="fleur" width="380px" height="200px">
<p>
Si le parfum est probablement notre accessoire le plus<br> intime, il est souvent le reflet d’un trait de caractère <br>que nous partageons avec d’autres femmes. En matière <br>de fragrances, on dénote quelques grandes tendances. <br>"Les femmes extraverties préfèrent les tons <br>vétiver du parfum
</p>
</div>

<div  class="psy">
<h5> la vie est belle avec un parfum</h5> 
<img  class="rota" src="images/best.jpg" alt="fleur" width="380px" height="200px">
<p>
Les parfums habillent notre intimité. Comme une robe<br> couvre notre nudité et souligne la rondeur d’un sein ou<br> la courbe d’une hanche, le parfum, en masquant notre<br> odeur corporelle, raconte ce que nous avons envie d’être.<br> Il est un langage qui nous permet d’exprimer <br>qui nous sommes.
</p>
</div>
</div>
<div class="black">
 <footer >
  <p id="log"> <a href="login.php">se connecter</a></p>
   <img src="images/icones.jpg" alt="social_media" width="200px" height="40px" usemap="#cliquable">
    <map name="cliquable">
        <area shape="rect" coords="1,1,40,50" href="https://www.instagram.com/">
        <area shape ="rect" coords="45,1,85,50" href="https://twitter.com/"  > 
        <area shape ="rect" coords="87,1,120,50" href="https://facebook.com"  > 
        <area shape="rect" coords="125,1,160,50" href="https://www.pinterest.fr/"  >
        <area shape="rect" coords="163,1,198,50" href="https://www.linkedin.com/"  >
	</map>
	<div class="info">
	 <div style="color:white">
	 <p >Toujours la Pour Vous !</p><br>
	 <p>Vous Mérité le meilleur !</p>
	 </div>
	 <h6 style="color:black">Copyright © 2021 Perfuma™ </h6>
  </footer>
 </div>
</body>

</html>