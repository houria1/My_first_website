<?php
session_start();
session_destroy();
echo "You seccessfully log out 👍"."<br>";
echo "<a href='login.php' >login again </a>";

echo "or click here to go back to <a href='index.php'>Home</a>";

?>