<!DOCTYPE html>
<html>
    <head>
    <title>Login Form/new</title>
    <link type="text/css" rel="stylesheet" href="css/template.css">
    <meta charset="UTF-8">
  
    </script>
    </head>
    <body>
    <script type="text/javascript" src="javascipt.js"></script>

        <form method="post" id="form_login" > 
        <h1>Create Account</h1>

        <div class="form_grp">
            <label for="Nom">Username</label>
            <input name="username" type="text" class="form-control" required>
        </div>


        <div class="form_grp">
            <label for="Email">Useremail </label>
            <input name="email" type="text" class="form-control" required>
        </div>

        <div class="form_grp">
            <label for="Mot de passe">Password </label>
            <input name="mdp" type="password" class="pw" required>
           
        </div>
            

        <div class="form_grp">
            <label for="Mot de passe">Confirm :  </label>
            <input name="mdp2" type="password" class="pw" required>
            <input type="checkbox" onclick="hidepw()" id='check' >Show Password
        </div>


        <div class="form_grp">
            <input type="checkbox" name="remem" id="remember">
            <label for="Remember me!">Rememberme!</label>
        </div>

        <div class="form_grp">
            <div><input type="submit" name="login" value="Create Account" id="btn_login" required></span> </div>   

        </div>

        </form>

<?php
 
 if(isset($_POST['login'])){
       $usernm=$_POST['username'];
        $email=$_POST['email'];
       $passsword=$_POST['mdp'];   
       $passsword2=$_POST['mdp2'];


       if($passsword !=$passsword2)
       {
           echo "<script>alert(\"Passwords do not match\")</script>";
       }

     try{
          $bdd = new PDO("mysql:host=localhost;dbname=user;charset=utf8","root","");
     } 
       catch (Exception $e){
         die("Erreur: ".$e->getMessage());

            }

            
              $reponse = $bdd->prepare('INSERT INTO table_login( USERNAME, EMAIL, pass_word) VALUES (:nom,:email,:pasword)');
            //  $reponse->bindParam(":nom", $usernm , PDO::PARAM_STR);
            //  $reponse->bindParam(":email", $email, PDO::PARAM_STR);
             // $reponse->bindParam(":password", $passsword, PDO::PARAM_STR);
  
          $reponse->execute(array('nom'=>$usernm , 'email'=>$email , 'pasword'=>$passsword));
         // $donnee=$reponse->fetch();
        if($reponse->execute(array('nom'=>$usernm , 'email'=>$email , 'pasword'=>$passsword))){
         echo 'You seccesfully create Account 👍'."<br>";
          echo "<a href='login.php' >Go back to login page</a>";
        }else{
            echo "<script>alert(\"Passwords do not match\")</script>";
        }



}

?>