<?php
$prenom=$_POST["prenom_input"];

$nom=$_POST["name_input"];

$email=$_POST["email_input"];
$commande=$_POST["choix"];

$tab=array("Votre Prenom"=>$prenom , "Votre nom"=>$nom , "Votre email"=>$email , "Votre ID"=>$id= $nom."123" , "Votre commande"=>$commande);

if (filter_var($_POST["email_input"], FILTER_VALIDATE_EMAIL)) 
{
      echo "L'adresse email saisi est considérée comme valide."."<br>"."<br>";
	  
	echo "Vous trouvez ci dessous un recapulatif de votre commande : "."<br>";
	
	foreach($tab as $key=>$value)
	{
		
		echo "***";

		echo  " $key = $value<br><br><hr>";
	}
	
	echo "<b>"."Rendez vous evec le meilleur chez Perfuma ;)"."</b>"."<br>";
	echo "<a href=commande.php ><---Revenir</a>";
}
else 
{

    echo "L'adresse email saisi est considérée comme invalide"."<br>";
	echo "<a href=commande.php ><---Revenir</a>";
}	 
?>