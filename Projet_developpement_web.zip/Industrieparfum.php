<!DOCTYPE html>
<html lang="fr">
<head>
<title>Perfuma/Industrie des Parfums</title>
<meta charset="UTF-8">
<link type="text/css" rel="stylesheet" href="css/template.css">
</head>

<body>

<script src="javascipt.js"></script>


<div class="loader_container"> 
  <div class="loader"></div> 
</div>
<div class="black">
<nav >

     <ul>
	   
       
      <li><a href ="index.php">Home</a></li>
      <li><a href = "Industrieparfum.php">Industrie des Parfums</a></li>
          <li><a href = "commande.php">Commande</a></li>
          <li><a href = "PsycoParfum.php">PsycoParfum</a></li>
          <li><a href = "historique.php">Historique</a></li>
       
	</ul>	
</nav>
<div class="popup" onclick="ma_fonction()">Click me!
  <span class="popup_text" id="mon_popup"> 🌹  إستغفر الله  🌹 </span>
</div>
</div>
<?php

session_start();
if(session_status() == 2 and !empty($_SESSION)){
  
 
  
     echo "<b><p style='font-size:20px ; color:hotpink ; border-left:solid'>Welcome🔔 :)"." ". $_SESSION['username']."<br>";
      echo "<a href='logout.php' style='font-size:20px ; color:hotpink ; hover:white' >logout</a>";


}
     
?>
      
<video controls >
<source src="images/vid.mp4" type="video/mp4" >
</video>

<h3 class="rose">L'expression pour l'obtention de l'odeur des agrumes </h3>
<p class="ancien" >
L'expression est un procédé d'extraction réservé uniquement aux agrumes. Il s'emploie aussi bien pour la création de parfums pour hommes que de fragrances pour femmes. L'expression est une méthode d'extraction par pression. Cependant, seule l'écorce des fruits hespéridés est suffisamment riche et odorante pour pouvoir s'exprimer simplement et directement sous la forme d'une essence naturelle. L'écorce est tout d'abord séparée du fruit. Elle est ensuite percée de petits trous de façon mécanique jusqu’à ce que l'on en obtienne le zeste. L'extrait de fruits obtenus est ensuite décanté et filtré sur du papier mouillé. Ainsi, le parfumeur sépare les parties aqueuses des huiles essentielles. Aujourd'hui, ce moyen de fabrication est essentiellement réalisé à l'aide de centrifugeuses. En effet, une expression manuelle reviendrait bien trop cher aux parfumeurs, d'où la mécanisation de cette technique ancestrale. Ce procédé permet d’obtenir une odeur très fraîche et vivifiante.
</p>
<h3 class="rose">  La distillation en parfumerie</h3>
<p class="ancien">
La distillation consiste à séparer par évaporation les différents constituants volatils d'un mélange. Cette opération se fait à l'aide d'un alambic. Cet appareil est une sorte de cuve en acier sur laquelle a été monté un tuyau dans lequel on dépose l'ensemble des végétaux nécessaires à la réalisation d'un parfum associés à cinq à dix fois leur volume en eau. Ce mélange d'eau et de végétaux très odorants est ensuite chauffé à haute température et mis sous pression. La vapeur d'eau produite entraine alors les éléments parfumés dans la colonne de distillation. Ces derniers sont ensuite refroidis et recueillis dans ce que l'on appelle un vase florentin (autrement appelé essencier). C'est alors que l'étape de la décantation intervient. En effet, la séparation des différents éléments se fait automatiquement par différence de densité étant donné que les deux liquides sont peu miscibles. L’eau se sépare donc progressivement des éléments odorants. C'est précisément ceux-ci
</p>

<h3 class="rose"> L'extraction pour obtenir du parfum</h3>

<p class="ancien">L'extraction est une méthode qui consiste à laisser infuser des matières végétales dans de l'eau et du solvant portés à 60°. Autrefois, l'eau était même remplacée par des huiles. Toutefois, cette époque est aujourd'hui bien révolue. Afin de réaliser cette opération, les parfumeurs utilisent différents types de solvants. Il peut s'agir de méthanol, d'éthanol, de benzène ou de dioxyde de carbone. Ces derniers sont choisis en fonction du type de plantes à traiter. Chacun de ces produits est volatil. Ainsi, lorsque le mélange est chauffé, les solvants s'évaporent petit à petit jusqu'à ce qu'il ne reste qu'une sorte de cire que l'on appelle la « concrète ». Cette dernière est ensuite mélangée à une dose d'alcool que l'on chauffe de façon à éliminer la partie huileuse. Une fois purifiée des composants végétaux et des cires qu’elle contient, la concrète devient ce que l'on appelle l'absolue. </p>
<figure><figcaption align="center"><b>le monde de l'industruie des parfum</b></figcaption>
 <img src="images/in.jpg" alt="Parfum"  width="30%" height="40%">
 <img src="images/ind.jfif" alt="Parfum"  width="30%" height="40%">
 <img src="images/inn.jfif" alt="Parfum"  width="30%" height="40%">
 </figure>
<h3 class="rose">L'enfleurage pour créer des parfums </h3>
<p class="ancien">
L'enfleurage peut être réalisé à chaud et à froid. Ces méthodes s'emploient en fonction du type de plantes à traiter.
L'enfleurage à froid est un procédé particulièrement ancien qui a aujourd'hui presque totalement disparu. Néanmoins, il reste employé pour l'extraction des fleurs fragiles à l'instar de la fleur d'oranger, du jasmin ou des tubéreuses. Notons cependant qu'il s'agit d'une technique particulièrement coûteuse. Les pétales des fleurs sont ramassés à la main et sont disposés en fines couches sur une pellicule de graisse animale répandue sur une plaque de verre. Celle-ci est appelée le châssis. Toutes les 24 ou 48 heures (72 heures pour la tubéreuse), les pétales sont enlevés minutieusement et son remplacés par des fleurs fraîches. Cette opération est ensuite répétée jusqu'à saturation des graisses. La sorte de cire odorante obtenue est alors raclée et chauffée jusqu'à décantation par traitement éthylique. Le tout est ensuite filtré jusqu'à obtention de l'absolue.
</p>

<h3 class="rose"> Softact pour l'obtention d'une odeur la plus pure qui soit</h3>
<p class="ancien">
Le Softact est également nommé extraction par CO2. Ce nouveau procédé révolutionnaire utilise le gaz carbonique en tant que solvant. Le CO2 est placé sous la pression d'une température inférieure à 40°. Il passe donc au stade supercritique, c'est-à-dire liquide et ultra malléable. Les morceaux d'écorces ou de fleurs sont alors placés dans un système fermé dans lequel passe le CO2. Ce dernier est ensuite récupéré et permet d'obtenir des extraits de parfum d'une qualité olfactive incomparable. Les essences issues de ce procédé sont particulièrement pures et ne contiennent aucune trace de solvant. Le Softact est considéré comme étant une méthode d'extraction particulièrement douce. Cette technique permet d'extraire des substances odorantes peu volatiles, sèches ou récalcitrantes aux techniques traditionnelles. À titre indicatif, sachez qu'elle est particulièrement employée pour le traitement des épices.
</p>
<div class="black">
	
<footer >
  <p id="log"> <a href="login.php">se connecter</a></p>
   <img src="images/icones.jpg" alt="social_media" width="200px" height="40px" usemap="#cliquable">
    <map name="cliquable">
        <area shape="rect" coords="1,1,40,50" href="https://www.instagram.com/">
        <area shape ="rect" coords="45,1,85,50" href="https://twitter.com/"  > 
        <area shape ="rect" coords="87,1,120,50" href="https://facebook.com"  > 
        <area shape="rect" coords="125,1,160,50" href="https://www.pinterest.fr/"  >
        <area shape="rect" coords="163,1,198,50" href="https://www.linkedin.com/"  >
	</map>
	<div class="info">
	 <div style="color:white">
	 <p >Toujours la Pour Vous !</p><br>
	 <p>Vous Mérité le meilleur !</p>
	 </div>
	 <h6 style="color:black">Copyright © 2021 Perfuma™ </h6>
  </footer>
  </div>
</body>
</html>