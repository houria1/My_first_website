
function showcontent(){
  var banner =document.getElementsByClassName('loader_container');
  for(var i = 0; i < banner.length; i++)
  {
      banner[i].classList.add('hidden');
      }

}
 
 
 
setTimeout(showcontent, 2500); //element loader  se cache apres 3s

function ma_fonction() {
	
  var popup = document.getElementById("mon_popup");
  
  popup.classList.toggle("show");
}


function hidepw() {
  var content = document.getElementsByClassName('pw');
  var if_chek =document.getElementById('check');
  for(var i = 0; i < content.length; i++)
  {
    if(if_chek.checked)
    {
       content[i].setAttribute('type','text');
      }else
      {
         content[i].setAttribute('type','password');
 
      }
       
 
  

   }}


  

 


  
 
