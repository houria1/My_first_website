<!DOCTYPE html>
<html lang="fr">
 <head>
   <title>Perfuma/Commande</title>
   <meta charset="UTF-8">
   <link type="text/css" rel="stylesheet" href="css/template.css">
</head>
<body>


 <script src="javascipt.js"></script>

 
<div class="loader_container"> 
  <div class="loader"></div> 
</div>

<div class="black">
        <nav >

           <ul>
	   
                 <li><a href ="index.php">Home</a></li>
		        <li><a href = "Industrieparfum.php">Industrie des Parfums</a></li>
                <li><a href = "commande.php">Commande</a></li>
                <li><a href = "PsycoParfum.php">PsycoParfum</a></li>
                <li><a href = "historique.php">Historique</a></li>
       
	        </ul>	
        </nav>
		<div class="popup" onclick="ma_fonction()">Click me!
       <span class="popup_text" id="mon_popup"> 🌹  إستغفر الله  🌹 </span>
        </div>
  
</div> 
<?php

session_start();
if(session_status() == 2 and !empty($_SESSION)){
  
 
  
     echo "<b><p style='font-size:20px ; color:hotpink ; border-left:solid'>Welcome🔔 :)"." ". $_SESSION['username']."<br>";
      echo "<a href='logout.php' style='font-size:20px ; color:hotpink ; hover:white' >logout</a>";


}
     
?>
      
      

        <table border="2" width=60% style="border-color:pink" align="center" cellspacing="16" cellpadding="16"  >
         <caption  align="top" style="color:brown"><b>le meilleur pour <em>vous</em></b> </caption>
         <tr >
         <th>nom</th>
         <th>prix</th>
         <th>element principale</th>
         <th>%en alcohool</th>
         </tr>
         <tr>
		
		  <div class="imgcmd"> <img src="images/parfum1.JFIF" alt="monaliza">   <img src="images/parfum2.JFIF" alt="Soul">   <img src="images/parfum3.JFIF" alt="YOUE">   <img src="images/parfum4.JFIF" alt="Happy">   <img src="images/parfum5.JFIF" alt="Mme"></div>
         <td>Monaliza</td>
         <td>50$</td>
         <td>framboise</td>
         <td>5%</td>
         </tr>
         <tr>
         <td>Soul</td>
         <td>60$</td>
         <td>Orange</td>
         <td>2%</td>
         </tr>
         <tr>
         <td>YOUE</td>
         <td>40$</td>
         <td>lemon</td>
         <td>10%</td>
         </tr>
         <tr>
         <td>Happy</td>
         <td>80$</td>
        <td>strawberry</td>
         <td>0%</td>
        </tr>
		<tr>
         <td>Mme</td>
         <td>80$</td>
        <td>Apple</td>
         <td>0%</td>
        </tr>
       </table>
	   <p style="color:brown">---><b>Notre magazin est connu au niveau international!</b> </p>
	   <p style="color:brown">---><b>On mit a votre disposition Mme une collection exeptionelle a haute qualité!</b> </p>
	   <h2 style="color:black"  >Votre Commande :</h2>
	   <form class="form" name="commande" method="post" align="center"  action="traitement1.php">  
	   <table width="60%"   cellspacing="10" cellpadding="10">
	   <tr>
	   <td><em><b>Nom</b> :</em></td>
	   <td><input type="text" name="name_input" placeholder="Votre nom ici " required></td>
	   </tr>
	   <tr>
	   <td><em><b>Prenom</b> :</em></td>
	   <td><input type="text" name="prenom_input" placeholder="Votre prenom ici" required ></td>
	   </tr>
	    <tr>
	   <td><em><b>E-mail</b> :</em></td>
	   <td><input type="text" name="email_input" placeholder="Votre login" required></td>
	   </tr>
	   <tr>
	   <td><em><b>Votre Choix </b>:</em></td>
	   <td >
	   <select name="choix">
	   <option value="Monaliza" >monaliza</option>
	   <option value="YOUE">YOUE</option>
	   <option value="Happy" >Happy</option>
	   <option value="Hme" >Mme</option>
	   <option value="Soul" >Soul</option>
	   </select>
	   </td>
	   </tr>
	   <tr >
	   <td>
	   </td>
	   <td ><input  type="submit" value="Envoyé" name="submit_button" style="background-color:white" ></td>
	   </tr>
	   
	   </table>
	   </form>
	   <h3 align="center" style="color:brown" ><em>Merci pour votre Confience :)</em></h3>
	<div class="black">
    
	<footer >
    <p id="log"> <a href="login.php">se connecter</a></p>
   <img src="images/icones.jpg" alt="social_media" width="200px" height="40px" usemap="#cliquable">
    <map name="cliquable">
        <area shape="rect" coords="1,1,40,50" href="https://www.instagram.com/">
        <area shape ="rect" coords="45,1,85,50" href="https://twitter.com/"  > 
        <area shape ="rect" coords="87,1,120,50" href="https://facebook.com"  > 
        <area shape="rect" coords="125,1,160,50" href="https://www.pinterest.fr/"  >
        <area shape="rect" coords="163,1,198,50" href="https://www.linkedin.com/"  >
	</map>
	<div class="info">
	 <div style="color:white">
	 <p >Toujours la Pour Vous !</p><br>
	 <p>Vous Mérité le meilleur !</p>
	 </div>
	 <h6 style="color:black">Copyright © 2021 Perfuma™ </h6>
  </footer>
  </div>
  
    </body>
</html>