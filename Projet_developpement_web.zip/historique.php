<!DOCTYPE html>
<html lang="fr">
<head>
<title>Perfuma/historique</title>
<meta charset="UTF-8">
<link type="text/css" rel="stylesheet" href="css/template.css">
</head>
<body >
<script src="javascipt.js"></script>


<div class="loader_container"> 
  <div class="loader"></div> 
</div>
<div class="black">
<nav >

     <ul>
	   
       
      <li><a href ="index.php">Home</a></li>
      <li><a href = "Industrieparfum.php">Industrie des Parfums</a></li>
          <li><a href = "commande.php">Commande</a></li>
          <li><a href = "PsycoParfum.php">PsycoParfum</a></li>
          <li><a href = "historique.php">Historique</a></li>
	</ul>	
</nav>
<div class="popup" onclick="ma_fonction()">Click me!
  <span class="popup_text" id="mon_popup"> 🌹  إستغفر الله  🌹 </span>
</div>
</div>
<?php
 
 session_start();
 if(session_status() == 2 and !empty($_SESSION)){
   
  
   
      echo "<b><p style='font-size:20px ; color:hotpink ; border-left:solid'>Welcome🔔 :)"." ". $_SESSION['username']."<br>";
       echo "<a href='logout.php' style='font-size:20px ; color:hotpink ; hover:white' >logout</a>";

 
 }
?>
      
<h3>
<img src="images/his.JPG" alt="historique des parfums">
Le parfum à ses origines
</h3>
<p class="ancien">
Dès l'Antiquité, le parfum était présent dans les populations. Les peuples utilisaient les végétaux et les matières naturelles telles que les fleurs et les plantes aromatiques pour composer leurs fragrances. Les parfums prenaient la forme d'huiles parfumées, de baumes et ou de liqueurs. Certains parfums étaient brûlés en l'honneur des divinités, notamment par les Égyptiens et les Grecs. D'autres étaient portés par les populations et ce, peu importait leur rang social. Grâce à Cléopâtre, le parfum a été associé à la féminité. Une véritable révolution pour l'époque.
Au Moyen Âge, le parfum se raréfie. Il reste présent, mais son utilisation se limite, et sa composition se réduit aux plantes aromatiques. Grâce à la découverte de nouvelles contrées, les épices feront leur apparition dans les parfums comme dans la cuisine. L'utilisation de la distillation marquera un tournant dans l'histoire du parfum.

</p>
 
 <h3>
 <img src="images/hist.JPG" alt="historique des parfums" width="170px" height="249px"> 
L'époque des rois
</h3>
<p class="ancien">
La Renaissance est une période clé pour l'histoire de la France et celle du parfum, puisqu'elle marque l'arrivée des notes parfumées comme l'ambre, le jasmin, la vanille, le cacao, le poivre ou le musc. Les populations, et plus particulièrement les gens riches, aiment les parfums forts qui marquent leur rang social. Plus on se rapproche du Siècle des lumières, plus les parfums sont subtils. Les parfumeurs arrivent sur le marché et proposent leurs propres créations, mais aussi des parfums sur mesure. En France, une région se démarque en termes de parfum. Cette région, c'est la Provence. Grasse devient même la capitale du parfum. Les senteurs fleuries sont très prisées par les femmes, et la toute première eau de Cologne est commercialisée.

</p>

 <h3>
<img src="images/historique.JFIF" alt="historique des parfums" width="170px" height="249px">
 Le XIXe siècle et l'arrivée de nouvelles techniques</h3>
 
 <p class="ancien">
 Le XIXe siècle marque lui aussi un tournant majeur dans l'histoire du parfum. De nouvelles techniques d'extraction et de fabrication sont mises en place. Les parfumeries se multiplient et trouvent un véritable public. Parallèlement, on voit apparaître différentes gammes de parfums. Certains sont fabriqués à grande échelle et affichent des prix abordables, d'autres sont des produits de luxe. La parfumerie est de plus en plus considérée comme un art, mais le parfum tient une place de choix au quotidien. Dès le XIXe siècle, on parfume les lessives, on place des sachets parfumés dans les armoires, on parfume nos intérieurs, etc.
 </p>
<h3>
<img src="images/hi.jpg" alt="historique des parfums" width="170px" height="249px">
  Le XXe siècle et ses créateurs de parfums</h3>
<p class="ancien"> 
 Produit de la vie courante, le parfum est devenu un incontournable. Les hommes se parfument de plus en plus, et chaque personne a sa fragrance favorite. Le XXe siècle a vu naître de grands créateurs, mais aussi des parfums iconiques. Chanel crée en 1921 son célèbre Chanel N°5 ; peu de temps après, ce sont Guerlain et son Shalimar qui marqueront les esprits. La Seconde Guerre mondiale ralentira les productions, mais dès la fin du conflit, de nouveaux parfums sont sortis. Ces parfums existent encore : il s'agit de Miss Dior, de L'Air du Temps de Nina Ricci, etc.
 
<div class="black">
 
 <footer >
  <p id="log"> <a href="login.php">se connecter</a></p>
   <img src="images/icones.jpg" alt="social_media" width="200px" height="40px" usemap="#cliquable">
    <map name="cliquable">
        <area shape="rect" coords="1,1,40,50" href="https://www.instagram.com/">
        <area shape ="rect" coords="45,1,85,50" href="https://twitter.com/"  > 
        <area shape ="rect" coords="87,1,120,50" href="https://facebook.com"  > 
        <area shape="rect" coords="125,1,160,50" href="https://www.pinterest.fr/"  >
        <area shape="rect" coords="163,1,198,50" href="https://www.linkedin.com/"  >
	</map>
	<div class="info">
	 <div style="color:white">
	 <p >Toujours la Pour Vous !</p><br>
	 <p>Vous Mérité le meilleur !</p>
	 </div>
	 <h6 style="color:black">Copyright © 2021 Perfuma™ </h6>
  </footer>
   </div>
 </body>
 </html>
