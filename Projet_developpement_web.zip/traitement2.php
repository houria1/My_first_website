
<?php //penses a ajouter une sweet lert apres validation du form

// preparer ma requette

/*$myemail="houria.elazzouny@gmail.com";
$mypasswrd="123";
$myusername='lalak bent sidek';
*/

if(isset($_POST['login'])){
    try{
        $bdd = new PDO("mysql:host=localhost;dbname=user;charset=utf8","root","");
    } 
    catch (Exception $e){
        die("Erreur: ".$e->getMessage());
    
    }
     $usernm=$_POST['username'];
     $email=$_POST['email'];
     $passsword=$_POST['mdp'];
     $reponse = $bdd->prepare('SELECT * FROM table_login WHERE USERNAME =:nom AND EMAIL=:email AND pass_word=:pasword ');
    $reponse->execute(array('nom'=>$usernm , 'email'=>$email , 'pasword'=>$passsword));
    $donnee=$reponse->fetch();

    
     if($email==$donnee['EMAIL'] and $passsword==$donnee['pass_word'] and $usernm==$donnee['USERNAME']){
        $rem=$_POST['remem'];
        if(isset($rem)){
            setcookie('name',$usernm,time()+60*60*24*356);
            setcookie('email',$email,time()+60*60*24*356);
            
        }
        session_start();
            $_SESSION['username']=$usernm;
           

            header('Location: http://localhost/index.php');

    } 
    else{
        echo "Email or password is invalid.<br> click here to <a href='login.php'>Trey again</a> or <a  href='Create.php'>Create Account</a>";
    }


}

else{ //redirection vers le fichier login 
    header("location : http://localhost/login.php");

}

?>